import { useRef, useState } from 'react';
import './App.css';

function App() {
  
  let [profilePic,setProfilePic] = useState("https://cwcnova.com/wp-content/uploads/2017/01/dummy-profile-pic.png")

  let stateSelectRef=useRef();
  let msgLabelRef=useRef();
  let firstNameInputRef=useRef();
  let lastNameInputRef=useRef();
  let maleRBRef=useRef();
  let femaleRBRef=useRef();
  let ageInputRef=useRef();
  let maritalStatus;
  let selectedGender;
  let salutation;
  let languagesKnown={
    eng:false,
    tel:false,
    hin:false,
    tam:false
  }


  let onhandleSubmit=()=>{
    if(selectedGender === "male"){
      salutation="Mr."

    }else{
      if(maritalStatus === "single"){
      salutation="Miss."
      }else{
        salutation="Mrs."

      }
    }
    console.log(languagesKnown);
    msgLabelRef.current.innerHTML=` ${salutation}${firstNameInputRef.current.value} ${lastNameInputRef.current.value} from ${stateSelectRef.current.value} and your account has been created in Infosys Portal and you know ${languagesKnown.eng === true ? "English":""} ${languagesKnown.tel === true ? "Telugu":""} ${languagesKnown.hin === true ? "Hindi":""} ${languagesKnown.tam === true ? "Tamil":""} Languages`

  }

  return (
    <div className="App">
      <form>
        <h2>Infosys</h2>
        <h3>Signup Form</h3>
        <div>
          <label for="profile-pic" class="sr-only">Profile Pic:</label>
          <input type="file" id="profile-pic" name="profile-pic" hidden onChange={(e)=>{
            console.log(e.target.files);
       let selectedPath = URL.createObjectURL(e.target.files[0]);
       setProfilePic(selectedPath)
       console.log(selectedPath)
          }}></input>
        </div>
        <div>
          <div>
            <label for="profile-pic">
            <img src={profilePic} alt=""></img>
            </label >
          </div>
          <label>First Name:</label>
          <input placeholder='Initial-Name' ref={firstNameInputRef}></input>
        </div>
        <div>
          <label>Last Name:</label>
          <input placeholder='Name' ref={lastNameInputRef}></input>
        </div>
        <div>
          <label>Email:</label>
          <input type="email" placeholder='Email'></input>
        </div>
        <div>
          <label>Password:</label>
          <input  type="password" placeholder='password'></input>
        </div>
        <div>
          <label>age:</label>
          <input placeholder='Age' type='number'ref={ageInputRef} onChange={()=>{
            let age = Number(ageInputRef.current.value);
            if(age < 5){
              console.log(`Infant`);
         
            }else if(age >=5 && age <=10){
              console.log(`Kids`);

            }else if(age >=10 && age <=20){
              console.log(`Teen`);

            }else if(age >=20 && age <=30){
              console.log(`Young age`)

            }else if(age >=30 && age <=60){
              console.log(`Middle age`)

            }else if(age >=60 && age <=100){
              console.log(`Old age`)

            }else{
              console.log(`Invalid age`)

            }

          }}></input>
        </div>
        <div>
          <label>Gender:</label>
          <input type="radio" name="gender" ref={maleRBRef} onChange={()=>{
            if(maleRBRef.current.checked === true){
              selectedGender ="male"
            }

          }}></input>
          <label style={{width:"auto"}}>Male</label>
          <input type="radio" name="gender" ref={femaleRBRef} onChange={()=>{
            if(femaleRBRef.current.checked === true){
              selectedGender="female"

            }
          }}></input>
          <label style={{width:"auto"}}>Female</label>
        </div>
        <div>
          <label>Marital Status:</label>
          <input type="radio" name="ms" onChange={(e)=>{
            console.log(e);
            if(e.target.checked === true){
              maritalStatus="single"
              
            }

          }}></input>
          <label style={{width:"auto"}}>Single</label>
          <input type="radio" name="ms" onChange={(eo)=>{
            if(eo.target.checked === true){
              maritalStatus="married"

            }
          }}></input>
          <label style={{width:"auto"}}>Married</label>
        </div>
        <div>
          <label>Languages:</label>
          <input type="checkbox" onChange={(e)=>{
          languagesKnown.eng =  e.target.checked;
          }}></input>
          <label style={{width:"auto"}}>English</label>
          <input type="checkbox" onChange={(e)=>{
          languagesKnown.tel =  e.target.checked;
          }}></input>
          <label style={{width:"auto"}}>Telugu</label>
          <input type="checkbox" onChange={(e)=>{
          languagesKnown.hin =  e.target.checked;
          }}></input>
          <label style={{width:"auto"}}>Hindi</label>
          <input type="checkbox" onChange={(e)=>{
          languagesKnown.tam =  e.target.checked;
          }}></input>
          <label style={{width:"auto"}}>Tamil</label>
        </div>
        <div>
          <label>State:</label>
          <select ref={stateSelectRef}>
            <option>Select State</option>
            <option>Andhra Pradesh</option>
            <option>Telangana</option>
            <option>Karnataka</option>
            <option>Kerala</option>
            <option>Tamil Nadu</option>
            <option>Maharastra</option>
          </select>
        </div>
        <div>
          <label>Qualification:</label>
          <select>
            <option>Select Graduation</option>
            <option>MCA</option>
            <option>MBA</option>
            <option>B.Tech</option>
            <option>BSC</option>
            <option>BCA</option>
            <option>BBA</option>
            <option>BZC</option>
          </select>
 
        </div>
        <div>
          <label>College Name:</label>
          <input placeholder='College Name' type="text"></input>
        </div>
        <div>
          <button type="button" onClick={()=>{
            onhandleSubmit();

          }}>click here</button>
        </div>
        <div>
          <label ref={msgLabelRef} style={{width:"400px"}}></label>
        </div>

      </form>
      
    </div>
  );
}

export default App;
